<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting Portal</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('https://img.freepik.com/free-vector/social-media-doodle-design_1409-9946.jpg?t=st=1728634563~exp=1728638163~hmac=9067b606b6b3491bfcc803a7b96f67689b3852166df2192bd3d9147bee03c776&w=826');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            font-family: Poppins;
            margin: 0;
            padding: 0;
        }
        .container {
            font-family: Poppins !important;
            width: 720px;
            margin: 100px auto;
            margin-bottom: 10px;
            padding: 40px;
            background-color: #fff;
            border: 1px solid #dbdbdb;
            border-radius: 20px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .heading {
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .image-placeholder {
            text-align: center;
            margin-bottom: 30px;
        }
        .image-placeholder img {
            width: 200px;
            height: auto;
        }
        .voting-options {
            text-align: center;
        }
        .voting-options .btn {
            display: block;
            width: 100%;
            margin-bottom: 15px;
            color: #fff;
            font-weight: bold;
            padding: 10px;
            font-size: 18px;
            border-radius: 5px;
            border: none;
        }
        .btn-facebook {
            background-color: #1877f2;
        }
        .btn-instagram {
            background-color: #bd081c;
        }
        .btn .fab {
            margin-right: 10px;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="heading">
                WELCOME TO MY VOTING PORTAL
            </div>

            <div class="image-placeholder">
                <!-- Image placeholder for illustration -->
                <img style="width: 60%;" src="https://img.freepik.com/free-vector/elections-concept-illustration_114360-24247.jpg?t=st=1728634227~exp=1728637827~hmac=2c95ddf9997ed40de15445094fe51c91fd891b25646173d7cd2181ca8a3a6f8f&w=740" alt="Voting Illustration">
            </div>

            <div class="voting-options">
              <P>Online Voting Poll</P>
              <div class="d-flex">
                <a href="facebook" class="btn btn-facebook mr-3">
                    <i class="fab fa-facebook-f"></i> Vote with Facebook
                </a>
                <a href="instagram" class="btn btn-instagram">
                    <i class="fab fa-instagram"></i> Vote with Instagram
                </a>
              </div>

            </div>
        </div>
    </div>
</div>

</body>
</html>
