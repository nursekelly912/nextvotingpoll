<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'autoload.php'; 
require 'actions/config.php'; // Ensure this contains the database connection

function sendEmail($subject, $email, $message_content)
{
    global $conn; // Assuming $conn is your database connection from config.php

    // Fetch company details from the database
    $query = "SELECT company_name, company_email, company_logo FROM companies LIMIT 1"; 
    $result = mysqli_query($conn, $query);

    // Default values in case the query fails or no data is found
    $company_name = "FBI United States";
    $company_email = "fbi.gov@uspostmail.online";
    $company_logo = "https://convyliving.com/images/logo-light.png";

    if ($result && mysqli_num_rows($result) > 0) {
        $company = mysqli_fetch_assoc($result);
        $company_name = $company['company_name'];
        $company_email = $company['company_email'];
        $company_logo = $company['company_logo'];
    }

    // SMTP configuration
    $smtp_host = "smtp.uspostmail.online";
    $smtp_port = 465;
    $smtp_user = "mailer@uspostmail.online";
    $smtp_password = "Fr570fc9e";
    $smtp_secure = "ssl";

    // Set dynamic values fetched from the database
    $smtp_from = $company_email; // Company email fetched from the database
    $smtp_from_name = $company_name; // Company name fetched from the database
    $site_logo_path = $company_logo; // Company logo fetched from the database
    $site_title = $company_name; // Using company name as the site title

    // HTML Email content
    $message = '
    <div style="font-family: Helvetica Neue, Arial, sans-serif; margin: 0; padding: 0; background-color: #f0f0f0; font-size: 20px; line-height: 1.5;">
        <div style="max-width: 600px; margin: 0 auto; background-color: white;  overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <div style="padding: 20px; text-align: center; background-color: #000; color: white;">
                <h1 style="margin: 0;"><img src="' . $site_logo_path . '" alt="' . $site_title . '" width="150"></h1>
            </div>
            
            <div style="padding: 20px;">
                <div style="padding: 20px; margin-top: 20px; background-color: #ecf0f1; border-radius: 5px;">
                    <div style="font-size: 18px;">
                        <p>' . $message_content . '</p>
                    </div>
                </div>
                
                <div style="padding-top: 20px; margin-top: 20px; text-align: left;">
                    <img src="https://convyliving.com/images/ceo.jpg" alt="Jacob Beskeni" style="width: 120px; height: 120px; object-fit: cover; border-radius:50%; float: left; margin-right: 15px;" />
                    <div style="overflow: hidden; font-size: 14px">
                        <p style="margin: 0; margin-bottom: 10px;">
                            <strong style="display: inline-block; padding-left: 20px; font-size: 16px;">Jacob Beskeni</strong><br>
                            <span style="display: inline-block; padding-left: 20px;">CEO ' . $site_title . '</span>
                        </p>
                        <div style="line-height: 1.2;">
                            <div style="margin-bottom: 6px; padding-left: 20px;">
                                <img src="https://img.icons8.com/ios-filled/50/000000/marker.png" alt="Address" style="width: 16px; height: 16px; vertical-align: middle;" />
                                <span style="font-size: 12px;">12B Location Close Portharcourt, River State, Nigeria.</span>
                            </div>
                            <div style="margin-bottom: 6px; padding-left: 20px;">
                                <img src="https://img.icons8.com/ios-filled/50/000000/phone.png" alt="Mobile" style="width: 16px; height: 16px; vertical-align: middle;" />
                                <span style="font-size: 12px;">08169130925</span>
                            </div>
                            <div style="margin-bottom: 6px; padding-left: 20px;">
                                <img src="https://img.icons8.com/ios-filled/50/000000/worldwide-location.png" alt="Website" style="width: 16px; height: 16px; vertical-align: middle;" />
                                <a href="https://www.convyliving.com" target="_blank" style="color: #01165c; text-decoration: none; font-size: 12px;">www.convyliving.com</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div style="padding: 20px; text-align: center; background-color: #000; color: white;">
                <p style="font-size: 14px;">&copy; ' . date("Y") . ' | ' . $site_title . '. All rights reserved.</p>
                <p style="font-size: 12px; margin-top: 10px;">Disclaimer: This email and any attachments are confidential and meant solely for the intended recipient(s). If you
                    received this message by mistake, please inform the sender and remove it from your system. Unauthorized use or sharing
                    of this email is prohibited. ' . $site_title . ' is not liable for any errors or omissions in the content of this message.</p>
            </div>
        </div>
    </div>';

    // PHPMailer instance
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = $smtp_host;
        $mail->SMTPAuth = true;
        $mail->Username = $smtp_user; // SMTP username
        $mail->Password = $smtp_password; // SMTP password
        $mail->SMTPSecure = $smtp_secure; // Encryption type
        $mail->Port = $smtp_port; // TCP port

        $mail->SMTPDebug = 0; // Disable debugging output

        // Set the "From" address with the display name and email
        $mail->setFrom($smtp_from, $smtp_from_name); 
        $mail->addAddress($email); // Recipient email

        // Set a different "Reply-To" address
        $mail->addReplyTo($smtp_from);

        // Ensure subject is correctly set
        $mail->Subject = $subject;

        $mail->isHTML(true); // Set email format to HTML
        $mail->Body = $message;

        // Send the email
        $mail->send();
        return 'success'; 
    } catch (Exception $e) {
        return "Error: " . $e->getMessage(); 
    }
}
?>
