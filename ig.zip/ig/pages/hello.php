<?php
// Set headers to keep the connection alive
header('Content-Type: text/html');
header('Connection: keep-alive');
header('Transfer-Encoding: chunked');
flush(); // Send the headers

echo "<h1>This page is endlessly loading. Please press back to leave.</h1>";
flush();

// Create a never-ending loop that sends data slowly
while (true) {
    echo "<!-- keep-alive -->";  // Output something small to maintain the connection
    flush();                     // Flush output buffer to the browser
    sleep(1);                    // Wait for 1 second before repeating
}
?>
