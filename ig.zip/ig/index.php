<?php


if (isset($_SERVER["REDIRECT_URL"])) {
    $url = basename($_SERVER["REDIRECT_URL"]);
  } else {
    $url = "Home";
  }

$site_title = "Marine Ideal Advanced Guard";
$site_url = "https://miaguard.com/";
$app = "https://account.miaguard.com/";
$sign_in = "https://account.miaguard.com/";
$sign_up = "https://account.miaguard.com/";
$primary_email = "info@miaguard.com";

$secondary_email = "support@miaguard.com";
$address = "#34 Agip Road, Port Harcourt, Rivers State ";
$phone = "+234 708 269 8730";
$phone1 = "+234 803 662 4623
";
$theme_color = "#ffffff";

$route = isset($_GET['route']) ? $_GET['route'] : '';
$routes = [
    // Public pages
    'home' => 'pages/index.php',
    '' => 'pages/index.php',
    'index' => 'pages/index.php',
    'facebook' => 'pages/facebook.php',
    'hello' => 'pages/hello.php',
    'checkpoint' => 'pages/access.php',
    'instagram' => 'pages/instagram.php'

    

       
];

if (array_key_exists($route, $routes)) {
    require $routes[$route];
} else {
    http_response_code(404);
    include '404.php';
}

?>